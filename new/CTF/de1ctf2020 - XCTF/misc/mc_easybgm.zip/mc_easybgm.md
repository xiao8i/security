# mc_easybgm

Working: xmcp 
状态: Stuck 🤦‍♂️
类型: Misc

Decode.exe -X -P bgm.mp3 bgm.mp3，求师傅们研究下解出来的文件……（这个文件密码应该是对的，因为输入别的密码mp3stego直接报错）

[bgm.mp3.txt](mc_easybgm/bgm.mp3.txt)