# Easy Protocol

Working: xmcp 
状态: Stuck 🤦‍♂️
类型: Misc

hint是CAB压缩包，还有三个pcap

hint1: flag is De1CTF{part1_part2_part3}
hint2: The part1,part2 and part3 is a pure number with a length of 8

pcap里一堆LDAP、Kerberos、NTLM的东西，溜了